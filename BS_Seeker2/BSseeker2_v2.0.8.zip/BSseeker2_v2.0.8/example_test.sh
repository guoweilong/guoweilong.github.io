#!/usr/bin/env sh
# Guo, Weilong; guoweilong@126.com; 2014-08-12


# For -build.py
./bs_seeker2-build.py -f test_data/genome.fa --aligner=bowtie

./bs_seeker2-build.py -f test_data/genome.fa --aligner=bowtie2 -r

# For -align.py


# For -call_methylation.py



